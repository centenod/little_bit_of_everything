#!/bin/bash

read first
read second

$second 1>/home/pi/Desktop/ping/ping$first.txt
