#!/usr/bin/python3
import pingparsing
import csv
import os.path
import os
import subprocess
import shutil
import datetime

from multiprocessing import Process
from subprocess import Popen, PIPE, call



fileMissing = os.path.isfile('/home/pi/Desktop/ping/Average.csv')
with open('/home/pi/Desktop/ping/Average.csv','a',newline='') as appendfile:
    fieldnamesA = ['Time_Stamp','packet_loss_rate', 'rtt_mdev', 'packet_loss_count', 'packet_duplicate_rate', 'packet_duplicate_count', 'rtt_avg', 'destination', 'packet_receive', 'rtt_min', 'packet_transmit', 'rtt_max']
    w = csv.DictWriter(appendfile, fieldnames=fieldnamesA, dialect='excel-tab')
    
    if not fileMissing:
        w.writeheader()

packet_loss_rate =[]
rtt_mdev =[]
packet_loss_count =[]
packet_duplicate_rate =[]
packet_duplicate_count =[]
rtt_avg =[]
destination =[]
packet_receive =[]
rtt_min =[]
packet_transmit =[]
rtt_max =[]

with open('/home/pi/Desktop/ping/Data/ResultsFile.csv') as readfile, open('/home/pi/Desktop/ping/Average.csv','a',newline='') as appendfile:
    fieldnames = ['Time_Stamp','packet_loss_rate', 'rtt_mdev', 'packet_loss_count', 'packet_duplicate_rate', 'packet_duplicate_count', 'rtt_avg', 'destination', 'packet_receive', 'rtt_min', 'packet_transmit', 'rtt_max']
    reader = csv.DictReader(readfile, dialect='excel-tab')
    writer = csv.DictWriter(appendfile, fieldnames=fieldnames, dialect='excel-tab')
    for row in reader:
        print(row)
        rtt_mdev.append(float(row['rtt_mdev']))
    average2 = sum(rtt_mdev) / len(rtt_mdev)
    print(average2)
    print(rtt_mdev)
    
    
    now_time= datetime.datetime.now().strftime("%Y:%m:%d %H:%M:%S")
    writer.writerow({'Time_Stamp': now_time, 'rtt_mdev': average2})



