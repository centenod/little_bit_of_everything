#!/usr/bin/python3
import pingparsing
import csv
import os.path
import os
import subprocess
import shutil
import time

from multiprocessing import Process
from subprocess import Popen, PIPE, call

def run_ping():

    packets='10'
    size='250'
    target='8.8.8.8'
    #Process= Popen('./home/pi/Desktop/inputsh.sh %s %s' % (str(test_num), str(var2)), shell=True)
    output = subprocess.Popen(['ping', '-c', packets, '-s', size, target], stdout=subprocess.PIPE).communicate()[0]
    #Process= Popen(["./home/pi/Desktop/inputsh.sh %s %s" % (test_num, var2) ], stdin= PIPE, shell=True)
    
    outputToFile=output.decode('utf-8')
    print(outputToFile)
    print("Saving in data%i.txt" %i)
    with open('/home/pi/Desktop/ping/Data/data%i.txt' %i, 'w') as f:
        f.write(outputToFile)
    print("PROCESS FINISH")




    with open("/home/pi/Desktop/ping/Data/data%i.txt" %i,'r') as f, open("/home/pi/Desktop/ping/Data/ResultsFile.csv", 'a') as apnd:
        fieldnames = ['packet_loss_rate', 'rtt_mdev', 'packet_loss_count', 'packet_duplicate_rate', 'packet_duplicate_count', 'rtt_avg', 'destination', 'packet_receive', 'rtt_min', 'packet_transmit', 'rtt_max']
        w = csv.DictWriter(apnd, fieldnames=fieldnames, dialect='excel-tab')
        ping_parser.parse(f.read())
        w.writerow(ping_parser.as_dict())





shutil.rmtree('/home/pi/Desktop/ping/Data')
os.mkdir('/home/pi/Desktop/ping/Data')

ping_parser = pingparsing.PingParsing()
fileMissing = os.path.isfile("/home/pi/Desktop/ping/Data/ResultsFile.csv")


with open("/home/pi/Desktop/ping/Data/ResultsFile.csv", 'a') as apnd:
    fieldnames = ['packet_loss_rate', 'rtt_mdev', 'packet_loss_count', 'packet_duplicate_rate', 'packet_duplicate_count', 'rtt_avg', 'destination', 'packet_receive', 'rtt_min', 'packet_transmit', 'rtt_max']
    w = csv.DictWriter(apnd, fieldnames=fieldnames, dialect='excel-tab')
    if not fileMissing:
        w.writeheader()

#print('Grabbing process 1')
#p1 = Process(target=run_ping)
#print(p1)

p = []
j = 0
for i in range(0,25):
    print('Call number '+ str(j))
    pro = Process(target=run_ping)
    p.append(pro)
    p[j].start()
    j += 1
j = 0
for i in range(0,25):
    p[j].join()
    j += 1