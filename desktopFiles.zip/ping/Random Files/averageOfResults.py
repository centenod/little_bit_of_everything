import numpy as np
import csv


rtt = []
with open('ResultsFile.csv') as readfile:
	reader=csv.DictReader(readfile, dialect='excel-tab')
	for row in reader:
#		print(row['packet_loss_rate'])
		rtt.append(float(row['rtt_mdev']))
		print(row['rtt_mdev'])

average = sum(rtt) / len(rtt)
print('The mean value of rtt_mdev is: '+str(average))
