import csv

countSum = 0
k=0
count = 0
with open('/home/pi/telenor/piList.csv','r',newline='') as read:
	fieldnames=['Hostname','IP','Status','Countdown','Last update']
	r = csv.DictReader(read, fieldnames=fieldnames, dialect='excel-tab')
	next(r, None)
	for row in r:
		k = row['Countdown']
		print(k)
		countSum += float(k)
		count = count +1
print('Sum: ', countSum)
#countSum = float(countSum)
count = float(count)
countSum = countSum / count
print('Mean is ', countSum)



