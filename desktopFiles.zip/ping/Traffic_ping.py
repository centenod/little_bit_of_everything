#!/usr/bin/python3
import time
import os
import numpy as np
import datetime
from multiprocessing import Process
import sys, getopt

def run_ping(targetIP, multi):
   os.system('(bash Traffic_Ping.sh -t %s -i 0.5 -c 2 -m %s) &' %(targetIP, multi))
   time.sleep(12)
   os.system('(bash Traffic_Ping.sh -t %s -i 0.5 -c 2 -m %s) &' %(targetIP, multi))
   time.sleep(12)

def main(argv):
   targetIP = '192.168.5.1'
   interface = 'wlan0'
   interval = '0.5'
   count = '10'
   size = '1000'
   multi= 10



   try:
      opts, args = getopt.getopt(argv,"ht:m:",["target=","multi="])
   except getopt.GetoptError:
      print (' ')
      print ('               ERROR syntesis should be writen like:')
      print ('   Traffic_ping.py -t <targetIP> -m <multiplicator>')
      print ('   Traffic_ping.py -target <targetIP> -multi <multiplicator>')
      print (' ')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print (' ')
         print ('Usage:')
         print ('        Traffic_ping.py -t <targetIP> -m <multiplicator>')
         print ('        Traffic_ping.py -target <targetIP> -multi <multiplicator>')
         print (' ')
         sys.exit()
      elif opt in ("-t", "--target"):
         targetIP = arg
      elif opt in ("-m", "--multi"):
         multi =str(arg)
   print ('TargetIP =', targetIP)
   print ('Multiplicator =', multi)


   p = []
   j = 0
   parall_procc=1000
   for i in range(0,parall_procc):
      pro = Process(target=run_ping(targetIP, multi))
      p.append(pro)
      p[j].start()
      time.sleep(1)
      p[j].join()
      j += 1

if __name__ == "__main__":
   main(sys.argv[1:])
