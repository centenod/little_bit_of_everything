import subprocess, re, csv

list_of_ips = ["facebook.com", "google.com"]
avgTimeList = []
for ip in list_of_ips:
    ping_process = subprocess.Popen(['ping', '-c', '5', ip], stdout=subprocess.PIPE)
    print(ping_process)
    stdout = ping_process.stdout.read()
    match = re.search(r'\d*\.\d*\/(\d*\.\d*)\/\d*\.\d*\/\d*\.\d*', stdout)
    avg = match.group(1)
    avgTimeList.append([ip, avg])

with open('avgTimes.csv', 'w') as csvfile:
    csvWriter = csv.writer(csvfile, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
    for data in avgTimeList:
        csvWriter.writerow(data)