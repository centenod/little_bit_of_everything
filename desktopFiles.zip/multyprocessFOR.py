#!/usr/bin/python3

import os
import subprocess

from multiprocessing import Process

########################################################################

# First let's get the process id for just running this script

current = os.getpid()
print ("\nCurrent process:", current)

########################################################################

# Now let's launch another process and get the id.

def get_id():
    # This function gets the parent process id (pp) and the current
    # process id (p).
    
    pp = os.getppid()
    p = os.getpid()
    
    string[j]=subprocess.check_output(
        "ping -c 2 8.8.8.8",
        shell=True)
    
    print("parent process:", pp)
    print("current process:", p)
    print("PROCESS FINISH")

# Let's call the function get_id twice. The parent process should
# have the same id in both cases but the current processes will have 
# different ids.

p1 = Process(target=get_id)
p1.start()

p2 = Process(target=get_id)
p2.start()

p3 = Process(target=get_id)
p3.start()

p4 = Process(target=get_id)
p4.start()



p1.join()
p2.join()
p3.join()
p4.join()