import subprocess


#with open('output.txt','w') as out:
#	msginput =str(input('Command:'))
#	print(msginput)
#	l= msginput.split(' ')

#l='ls aux | less | grep python3'

#l="ping -c 8 8 8.8.8.8"
#	print(l)
string=subprocess.check_output(
    "ping -c 2 8.8.8.8"l,
    shell=True)
print(string)	
#out.write(str.subprocess.check_output(l))


