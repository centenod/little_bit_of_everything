#!/usr/bin/python3

import os
import subprocess

from multiprocessing import Process
from subprocess import Popen, PIPE

########################################################################

# First let's get the process id for just running this script

current = os.getpid()
print ("\nCurrent process:", current)

########################################################################

# Now let's launch another process and get the id.

def run_ping():

    
    
    #number of test
    test_num= 8
    var2="ping -c 15 8 8.8.8.8"
    host="8.8.8.8"
    #Process= Popen('./home/pi/Desktop/inputsh.sh %s %s' % (str(test_num), str(var2)), shell=True)
    output = subprocess.Popen(['ping', '-c', '8', '-s', '500', '8.8.8.8'], stdout=subprocess.PIPE).communicate()[0]
    #Process= Popen(["./home/pi/Desktop/inputsh.sh %s %s" % (test_num, var2) ], stdin= PIPE, shell=True)

    print("PROCESS FINISH")
    print(output.decode('utf-8'))

#for i range [0,10]
print("\nFirst call:")
p1 = Process(target=run_ping)
p1.start()
    
#for i range [0,10]
p1.join()
    
##How to chekc if is done?    