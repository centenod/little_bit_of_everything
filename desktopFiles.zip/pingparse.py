import pingparsing
import csv
import os.path

ping_parser = pingparsing.PingParsing()
fileMissing = os.path.isfile("/home/pi/Desktop/ping/onefile.txt")

with open("/home/pi/Desktop/ping/ping.txt",'r') as f, open("/home/pi/Desktop/ping/pingParseResults.txt", 'a') as apnd:
    fieldnames = ['packet_loss_rate', 'rtt_mdev', 'packet_loss_count', 'packet_duplicate_rate', 'packet_duplicate_count', 'rtt_avg', 'destination', 'packet_receive', 'rtt_min', 'packet_transmit', 'rtt_max']
    w = csv.DictWriter(apnd, fieldnames=fieldnames, dialect='excel-tab')
    if not fileMissing:
        w.writeheader()
    ping_parser.parse(f.read())
    w.writerow(ping_parser.as_dict())

#print("packet_transmit:", ping_parser.packet_transmit)
#print("packet_receive:", ping_parser.packet_receive)
#print("packet_loss:", ping_parser.packet_loss)
#print("rtt_min:", ping_parser.rtt_min)
#print("rtt_avg:", ping_parser.rtt_avg)
#print("rtt_max:", ping_parser.rtt_max)
#print("rtt_mdev:", ping_parser.rtt_mdev)
print(ping_parser.as_dict())
