#!/usr/bin/python3

import os
import subprocess

from multiprocessing import Process

########################################################################

# First let's get the process id for just running this script

current = os.getpid()
print ("\nCurrent process:", current)

########################################################################

# Now let's launch another process and get the id.

def run_ping():

    print("PROCESS START")
    
    string=subprocess.check_output(
        "ping -c 2 8.8.8.8",
        shell=True)
    print(string)	
    

    print("PROCESS FINISH")

# Let's call the function get_id twice. The parent process should
# have the same id in both cases but the current processes will have 
# different ids.

print("\nFirst call:")
p1 = Process(target=run_ping)
p1.start()
print("\nSecond call:")
p2 = Process(target=run_ping)
p2.start()

print("\nThird call:")
p3 = Process(target=run_ping)
p3.start()

p1.join()
p2.join()
p3.join()    
